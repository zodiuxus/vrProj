Beer hat attachment for safety helmet by Chrashice on Thingiverse: https://www.thingiverse.com/thing:5185050

Summary:
This is an attachment for safety helmets to convert it into a beer hat